package forest.view.render;

public interface Renderable 
{
    /*
     * 表示を更新する
     */
	public abstract void update();
}
